<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:73:"E:\phpstudy\WWW\position\public/../application/index\view\show\index.html";i:1539069273;}*/ ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>源创智讯</title>
    <link rel="stylesheet" href="/static/css/show/index.css">
    <link rel="stylesheet" href="/static/css/bootstrap.css">
    <link rel="stylesheet" href="/static/css/iconfont.css">
    <script src="/static/js/jquery.min.js"></script>
    <script src="https://cdn.bootcss.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>
<body>
<div class="content">
    <div class="row status-row">
        <div class="col-xs-4 col-md-4 status-cont">
            <span>4G</span>
            <span><i class="iconfont icon-xinhao5"></i></span>
            <span>中国移动</span>
        </div>
        <div class="col-xs-4 col-md-4 status-cont cont2">
            <span>12:12</span>
        </div>
        <div class="col-xs-4 col-md-4 status-cont">
            <span>12%</span>
        </div>
    </div>
    <div class="row stock-info">
        <div class="col-xs-4 col-md-4">
            <i class="iconfont icon-jtright"></i>
        </div>
        <div class="col-xs-4 col-md-4">
            <p class="cont2">银河证券</p>
            <i class="iconfont icon-arrow-up"></i>
        </div>
        <div class="col-xs-4 col-md-4">
            <i class="iconfont icon-refresh"></i>
        </div>
    </div>
    <div class="row sta-change">
        <div class="col-xs-3 col-md-3">
            买入
        </div>
        <div class="col-xs-3 col-md-3">卖出</div>
        <div class="col-xs-3 col-md-3">撤单</div>
        <div class="col-xs-3 col-md-3">持仓</div>
    </div>
    <div class="sta-cont">
        <div class="cont-kind">
            <img src="/static/images/flag.png" alt="">
            <p>人名币账户 CNY A股</p>
        </div>
        <div>
            <!--<ul class="cont-ul">-->
                <!--<li class="cont-li"><p>总资产</p><p>12312.00</p></li>-->
                <!--<li class="cont-li"><p>总资产</p><p>12312.00</p></li>-->
                <!--<li class="cont-li"><p>总资产</p><p>12312.00</p></li>-->
                <!--<li class="cont-li"><p>总资产</p><p>12312.00</p></li>-->
                <!--<li class="cont-li"><p>总资产</p><p>12312.00</p></li>-->
            <!--</ul>-->
            <div class="row cont-ul">
                <div class="col-xs-4 col-md-4">
                    <p class="cont-p1">12312</p>
                    <p class="cont-p2">总资产</p>
                </div>
                <div class="col-xs-4 col-md-4">
                    <p class="cont-p1">312312</p>
                    <p class="cont-p2">浮动盈亏</p>
                </div>
                <div class="col-xs-4 col-md-4">
                    <p class="cont-p1">321312</p>
                    <p class="cont-p2">总市值</p>
                </div>
            </div>
            <div class="row cont-ul">
                <div class="col-xs-4 col-md-4">
                    <p>12312</p>
                    <p class="cont-p2">可取</p>
                </div>
                <div class="col-xs-4 col-md-4">
                    <p>312312</p>
                    <p class="cont-p2">可用</p>
                </div>
                <div class="col-xs-4 col-md-4">
                    <button class="cont-btn">银证转账</button>
                </div>
            </div>
        </div>
        <div class="cir-center">
            <div class="circle cir-black"></div>
            <div class="circle cir-gray"></div>
            <div class="circle cir-gray"></div>
        </div>
        <div>
            <div></div>
            <div></div>
            <div></div>
        </div>
    </div>
    <div class="main-cont">
        <div class="row cont-title">
            <div class="col-xs-3 col-md-3">市值</div>
            <div class="col-xs-3 col-md-3">盈亏</div>
            <div class="col-xs-3 col-md-3">持仓/可用</div>
            <div class="col-xs-3 col-md-3">成本/现价</div>
        </div>
        <div class="cont">
            <div class="row cont-cont">
                <div class="col-xs-3 col-md-3">
                    <p>mouiodasdhsa</p>
                    <p>1232131</p>
                </div>
                <div class="col-xs-3 col-md-3">
                    <p>mouiodasdhsa</p>
                    <p>1232131</p>
                </div>
                <div class="col-xs-3 col-md-3">
                    <p>mouiodasdhsa</p>
                    <p>1232131</p>
                </div>
                <div class="col-xs-3 col-md-3">
                    <p>mouiodasdhsa</p>
                    <p>1232131</p>
                </div>
            </div>
            <div class="row cont-cont">
                <div class="col-xs-3 col-md-3">
                    <p>mouiodasdhsa</p>
                    <p>1232131</p>
                </div>
                <div class="col-xs-3 col-md-3">
                    <p>mouiodasdhsa</p>
                    <p>1232131</p>
                </div>
                <div class="col-xs-3 col-md-3">
                    <p>mouiodasdhsa</p>
                    <p>1232131</p>
                </div>
                <div class="col-xs-3 col-md-3">
                    <p>mouiodasdhsa</p>
                    <p>1232131</p>
                </div>
            </div>
            <div class="row cont-cont">
                <div class="col-xs-3 col-md-3">
                    <p>mouiodasdhsa</p>
                    <p>1232131</p>
                </div>
                <div class="col-xs-3 col-md-3">
                    <p>mouiodasdhsa</p>
                    <p>1232131</p>
                </div>
                <div class="col-xs-3 col-md-3">
                    <p>mouiodasdhsa</p>
                    <p>1232131</p>
                </div>
                <div class="col-xs-3 col-md-3">
                    <p>mouiodasdhsa</p>
                    <p>1232131</p>
                </div>
            </div>
        </div>
    </div>
    <div class="btn-foot">
        <div class="row">
            <div class="col-xs-3 col-md-3"><button class="btn btn-default">修改后计算</button></div>
            <div class="col-xs-3 col-md-3"><button class="btn btn-default">生成图片</button></div>
            <div class="col-xs-3 col-md-3"><button class="btn btn-default">返回首页</button></div>
            <div class="col-xs-3 col-md-3"><button class="btn btn-default">返回上页</button></div>
        </div>
    </div>
    <footer>
        <div class="row foot">
            <div class="col-xs-3 col-md-3">
                <i class="iconfont icon-shouye"></i>
                <p>首页</p>
            </div>
            <div class="col-xs-3 col-md-3">
                <i class="iconfont icon-hangqing"></i>
                <p>行情</p>
            </div>
            <div class="col-xs-3 col-md-3 red">
                <i class="iconfont icon-houdongfangiconfont01"></i>
                <p>自选</p>
            </div>
            <div class="col-xs-3 col-md-3">
                <i class="iconfont icon-icon-test"></i>
                <p>交易</p>
            </div>
        </div>
    </footer>
</div>
<script>
    $(function () {
        $('.pre-btn').click(function () {
            window.location.href='/index/show/index';
        });
    });
</script>
</body>
<script>
    var userName = 'http://www.riign.com';
    var myDate = new Date();
    var nowTime = myDate.toLocaleTimeString();
    watermark({watermark_txt:'充值点卡去除水印'+userName+" "+nowTime});
    function watermark(settings) {
        //默认设置
        var defaultSettings={
            watermark_txt:"text",
            watermark_x:60,//水印起始位置x轴坐标
            watermark_y:60,//水印起始位置Y轴坐标
            watermark_rows:20,//水印行数
            watermark_cols:20,//水印列数
            watermark_x_space:80,//水印x轴间隔
            watermark_y_space:50,//水印y轴间隔
            watermark_color:'#aaa',//水印字体颜色
            watermark_alpha:0.4,//水印透明度
            watermark_fontsize:'36px',//水印字体大小
            watermark_font:'微软雅黑',//水印字体
            watermark_width:340,//水印宽度
            watermark_height:180,//水印长度
            watermark_angle:16//水印倾斜度数
        };
        //采用配置项替换默认值，作用类似jquery.extend
        if(arguments.length===1&&typeof arguments[0] ==="object" )
        {
            var src=arguments[0]||{};
            for(key in src)
            {
                if(src[key]&&defaultSettings[key]&&src[key]===defaultSettings[key])
                    continue;
                else if(src[key])
                    defaultSettings[key]=src[key];
            }
        }

        var oTemp = document.createDocumentFragment();

        //获取页面最大宽度
        var page_width = Math.max(document.body.scrollWidth,document.body.clientWidth);
        var cutWidth = page_width*0.0150;
        var page_width=page_width-cutWidth;
        //获取页面最大高度
        var page_height = Math.max(document.body.scrollHeight,document.body.clientHeight)+450;
        // var page_height = document.body.scrollHeight+document.body.scrollTop;
        //如果将水印列数设置为0，或水印列数设置过大，超过页面最大宽度，则重新计算水印列数和水印x轴间隔
        if (defaultSettings.watermark_cols == 0 || (parseInt(defaultSettings.watermark_x + defaultSettings.watermark_width *defaultSettings.watermark_cols + defaultSettings.watermark_x_space * (defaultSettings.watermark_cols - 1)) > page_width)) {
            defaultSettings.watermark_cols = parseInt((page_width-defaultSettings.watermark_x+defaultSettings.watermark_x_space) / (defaultSettings.watermark_width + defaultSettings.watermark_x_space));
            defaultSettings.watermark_x_space = parseInt((page_width - defaultSettings.watermark_x - defaultSettings.watermark_width * defaultSettings.watermark_cols) / (defaultSettings.watermark_cols - 1));
        }
        //如果将水印行数设置为0，或水印行数设置过大，超过页面最大长度，则重新计算水印行数和水印y轴间隔
        if (defaultSettings.watermark_rows == 0 || (parseInt(defaultSettings.watermark_y + defaultSettings.watermark_height * defaultSettings.watermark_rows + defaultSettings.watermark_y_space * (defaultSettings.watermark_rows - 1)) > page_height)) {
            defaultSettings.watermark_rows = parseInt((defaultSettings.watermark_y_space + page_height - defaultSettings.watermark_y) / (defaultSettings.watermark_height + defaultSettings.watermark_y_space));
            defaultSettings.watermark_y_space = parseInt(((page_height - defaultSettings.watermark_y) - defaultSettings.watermark_height * defaultSettings.watermark_rows) / (defaultSettings.watermark_rows - 1));
        }
        var x;
        var y;
        for (var i = 0; i < defaultSettings.watermark_rows; i++) {
            y = defaultSettings.watermark_y + (defaultSettings.watermark_y_space + defaultSettings.watermark_height) * i;
            for (var j = 0; j < defaultSettings.watermark_cols; j++) {
                x = defaultSettings.watermark_x + (defaultSettings.watermark_width + defaultSettings.watermark_x_space) * j;

                var mask_div = document.createElement('div');
                mask_div.id = 'mask_div' + i + j;
                mask_div.className = 'mask_div';
                mask_div.appendChild(document.createTextNode(defaultSettings.watermark_txt));
                //设置水印div倾斜显示
                mask_div.style.webkitTransform = "rotate(-" + defaultSettings.watermark_angle + "deg)";
                mask_div.style.MozTransform = "rotate(-" + defaultSettings.watermark_angle + "deg)";
                mask_div.style.msTransform = "rotate(-" + defaultSettings.watermark_angle + "deg)";
                mask_div.style.OTransform = "rotate(-" + defaultSettings.watermark_angle + "deg)";
                mask_div.style.transform = "rotate(-" + defaultSettings.watermark_angle + "deg)";
                mask_div.style.visibility = "";
                mask_div.style.position = "absolute";
                mask_div.style.left = x + 'px';
                mask_div.style.top = y + 'px';
                mask_div.style.overflow = "hidden";
                mask_div.style.zIndex = "9999";
                mask_div.style.pointerEvents='none';//pointer-events:none  让水印不遮挡页面的点击事件
                //mask_div.style.border="solid #eee 1px";
                mask_div.style.opacity = defaultSettings.watermark_alpha;
                mask_div.style.fontSize = defaultSettings.watermark_fontsize;
                mask_div.style.fontFamily = defaultSettings.watermark_font;
                mask_div.style.color = defaultSettings.watermark_color;
                mask_div.style.textAlign = "center";
                mask_div.style.width = defaultSettings.watermark_width + 'px';
                mask_div.style.height = defaultSettings.watermark_height + 'px';
                mask_div.style.display = "block";
                oTemp.appendChild(mask_div);
            };
        };
        document.body.appendChild(oTemp);
    }
</script>
</body>
</html>