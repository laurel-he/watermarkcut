<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:74:"E:\phpstudy\WWW\position\public/../application/index\view\index\index.html";i:1538983275;}*/ ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>源创智讯</title>
    <link rel="stylesheet" href="/static/css/index/index.css">
    <link rel="stylesheet" href="/static/css/bootstrap.css">
    <link rel="stylesheet" href="/static/css/bootstrap.css">
    <script src="/static/js/jquery.min.js"></script>
</head>
<body>
<div class="content">
    <div class="header">
        <div class="head-logo">
            <img src="/static/images/logo.png" alt="">
        </div>
        <div class="head-cont">
            <p class="p-title">基础设置</p>
            <div><span>请输入运营商：</span><input type="text"></div>
            <div><span>请输入时间（用当前时间则不输入）：</span><input type="text"></div>
            <div><span>请输入电量：</span><input type="text"></div>
            <div>
                <span>请选择手机类型：</span>
                <select>
                    <option value="0">安卓</option>
                    <option value="1">苹果</option>
                </select>

            </div>
            <div>
                <span>请选择证券公司：</span>
                <select>
                    <option value="0">中信证券</option>
                    <option value="1">华泰证券</option>
                </select>
            </div>
        </div>
        <div class="data-cont">
            <p class="p-title">数据输入</p>
            <div><span>可用：</span><input type="text"></div>
            <div><span>持仓信用金：</span><input type="text"></div>
            <div><span>手续费（千分之）：</span><input type="text"></div>
        </div>
        <div class="stock-input">
            <p class="p-title">股票输入</p>
            <aside class="bdrbottom3">
                <ul class="paddingmu">

                    <li class="col-mulu">
                        <p class="t-center">股票代码</p>
                    </li>
                    <li class="col-mulu">
                        <p class="t-center">到期</p>
                    </li>
                    <li class="col-mulu">
                        <p class="t-center">买入</p>
                    </li>
                    <li class="col-mulu">
                        <p class="t-center">成本</p>
                    </li>
                    <li class="col-mulu">
                        <p class="t-center">数量</p>
                    </li>
                    <li class="col-min">
                        <p class="t-center">显示</p>
                    </li>
                    <li class="col-min">
                        <p class="t-center">卖出</p>
                    </li>
                </ul>
                <ul class="paddingtb">

                    <li class="co">
                        <input name="daima11" type="text" value="sz002828" class="t-center">
                    </li>
                    <li class="co">
                        <input name="daoqi1-1" type="text" value="2018-5-1" class="t-center">
                    </li>
                    <li class="co">
                        <input name="mairu1-1" type="text" value="2018-5-1" class="t-center">
                    </li>
                    <li class="co">
                        <input name="chengben11" type="text" value="16.2" class="t-center">
                    </li>
                    <li class="co">
                        <input name="shuliang1" type="text" value="300" class="t-center">
                    </li>
                    <li class="col-min">
                        <input name="xianshi[]" type="checkbox" class="check" checked="true" value="1">
                    </li>
                    <li class="col-min">
                        <input name="maichu[]" value="1" type="checkbox" class="check">
                    </li>
                </ul>
                <ul class="paddingtb">
                    <li class="co">
                        <input name="daima21" type="text" value="sz000625" class="t-center">
                    </li>
                    <li class="co">
                        <input name="daoqi2-1" type="text" value="2018-5-1" class="t-center">
                    </li>
                    <li class="co">
                        <input name="mairu2-1" type="text" value="2018-5-1" class="t-center">
                    </li>
                    <li class="co">
                        <input name="chengben21" type="text" value="9.20" class="t-center">
                    </li>
                    <li class="co">
                        <input name="shuliang2" type="text" value="300" class="t-center">
                    </li>
                    <li class="col-min">
                        <input name="xianshi[]" value="2" type="checkbox" class="check">
                    </li>
                    <li class="col-min">
                        <input name="maichu[]" value="2" type="checkbox" class="check">
                    </li>
                </ul>
                <ul class="paddingtb">
                    <li class="co">
                        <input name="daima31" type="text" value="sz000651" class="t-center">
                    </li>
                    <li class="co">
                        <input name="daoqi3-1" type="text" value="2018-5-1" class="t-center">
                    </li>
                    <li class="co">
                        <input name="mairu3-1" type="text" value="2018-5-1" class="t-center">
                    </li>
                    <li class="co">
                        <input name="chengben31" type="text" value="49.3" class="t-center">
                    </li>
                    <li class="co">
                        <input name="shuliang3" type="text" value="300" class="t-center">
                    </li>
                    <li class="col-min">
                        <input name="xianshi[]" value="3" type="checkbox" class="check">
                    </li>
                    <li class="col-min">
                        <input name="maichu[]" value="3" type="checkbox" class="check">
                    </li>
                </ul>
                <ul class="paddingtb">
                    <li class="co">
                        <input name="daima41" type="text" value="sz000735" class="t-center">
                    </li>
                    <li class="co">
                        <input name="daoqi4-1" type="text" value="2018-5-1" class="t-center">
                    </li>
                    <li class="co">
                        <input name="mairu4-1" type="text" value="2018-5-1" class="t-center">
                    </li>
                    <li class="co">
                        <input name="chengben41" type="text" value="15.36" class="t-center">
                    </li>
                    <li class="co">
                        <input name="shuliang4" type="text" value="500" class="t-center">
                    </li>
                    <li class="col-min">
                        <input name="xianshi[]" value="4" type="checkbox" class="check">
                    </li>
                    <li class="col-min">
                        <input name="maichu[]" value="4" type="checkbox" class="check">
                    </li>

                </ul>
                <ul class="paddingtb">
                    <li class="co">
                        <input name="daima51" type="text" value="sz002607" class="t-center">
                    </li>
                    <li class="co">
                        <input name="daoqi5-1" type="text" value="2018-5-1" class="t-center">
                    </li>
                    <li class="co">
                        <input name="mairu5-1" type="text" value="2018-5-1" class="t-center">
                    </li>
                    <li class="co">
                        <input name="chengben51" type="text" value="14.2" class="t-center">
                    </li>
                    <li class="co">
                        <input name="shuliang5" type="text" value="300" class="t-center">
                    </li>
                    <li class="col-min">
                        <input name="xianshi[]" value="5" type="checkbox" class="check">
                    </li>
                    <li class="col-min">
                        <input name="maichu[]" value="5" type="checkbox" class="check">
                    </li>
                </ul>
                <p>
                    温馨提示：股票代码输入，上海证券需要在代码前输入“sh”,深圳证券需要在代码前输入“sz”
                </p>
            </aside>
        </div>
    </div>
    <div class="pre-see">
        <button class="btn btn-default pre-btn">预览</button>
    </div>
</div>
<script>
    $(function () {
        $('.pre-btn').click(function () {
            window.location.href='/index/show/index';
        });
    });
</script>
</body>
</html>s