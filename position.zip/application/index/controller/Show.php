<?php
namespace app\index\controller;

use think\Controller;

class Show extends Controller
{
    public function index()
    {
        if($this->request->isAjax())
        {
            echo 1231231;
        }
        return $this->view->fetch();
    }
}